stars数量在100-10000，最近推送日期在4年内

```shell
stars:100..10000 pushed:>YYYY-MM-DD
```

