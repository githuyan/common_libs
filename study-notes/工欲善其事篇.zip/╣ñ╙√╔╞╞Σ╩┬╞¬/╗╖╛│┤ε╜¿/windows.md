#### windows查看版本号

```python
# 控制台
winver
```



#### windows同局域网文件互传

> ==不完整== 还要在本地添加一个新的账户，然后由另一台电脑连接这个新账户



<img src="../../../resource/image-20221013110119023.png" alt="image-20221013110119023" style="zoom:80%;" />



1. 在防火墙下安装软件
windows安全中心 - 病毒和威胁防护 - “病毒和威胁防护”设置（管理设置） - 排除项（添加或删除排除项）

2. 关闭当前窗口退出
Alt + F4

3. 查询windows版本号
控制台 winver

4. windows中 快速打开git bash
shift+f10 - s（选中）- enter（确认）

5. edge浏览器快捷键
- 关闭窗口 ctrl+w
- 进入地址栏  f6 | ctrl+l | alt+d

6. windows最大化 | 最小化 快捷键
win+ ↑：最大化窗口
win+ ↓：最小化窗口
win + ←：最大化窗口到左侧的屏幕上
win + →：最大化窗口到右侧的屏幕上
