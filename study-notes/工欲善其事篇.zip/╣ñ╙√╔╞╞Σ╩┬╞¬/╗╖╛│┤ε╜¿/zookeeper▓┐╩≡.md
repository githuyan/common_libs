### docker-compose部署单机zookeeper

**参考：**

- [(14条消息) Docker docker-compose安装zookeeper单节点_我是大月饼的博客-CSDN博客](https://blog.csdn.net/Youdmeng/article/details/110553499) 



