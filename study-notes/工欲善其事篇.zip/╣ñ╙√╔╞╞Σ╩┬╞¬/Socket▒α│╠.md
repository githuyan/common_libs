## Socket

**参考：**  

1. [python socket编程 - 刘江的python教程 (liujiangblog.com)](https://www.liujiangblog.com/course/python/76)
2. [python版websocket - 简书 (jianshu.com)](https://www.jianshu.com/p/e3fe5805e51c) -- **极好**



![python socket编程 - 刘江的python教程](../../resource/1762677-20201007160746044-1258982359-16760257230411.png)

