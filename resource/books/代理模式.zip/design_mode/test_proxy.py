from proxy import *


def testProxy():
    realObj = RealSubject('RealSubject')
    proxyObj = ProxySubject('ProxySubject', realObj)
    proxyObj.request()


def testReceiveParcel():
    tony = OwnerReception("Tony", "18512345678")
    print("本人接收：")
    tony.request("雪地靴")
    print()

    print("Wendy代收：")
    wendy = WendyReception("Wendy", tony)
    wendy.request("雪地靴")


def testAgentReception():
    tony = OwnerReception("Tony", "18512345678", '北京')
    print("本人接收：")
    tony.request("雪地靴")
    print()

    print("驿站代收：")
    wendy = AgentReception("驿站-北京", tony)
    wendy.request("雪地靴")


# testProxy()
testReceiveParcel()
testAgentReception()
