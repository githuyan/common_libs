"""
代理模式：
    - 不方便使用真实角色去做，需要第三方替代
    - 代理真实角色后，一般会做一些附属的操作
举例：
    - 快递
    - 谍战片，中间联络人
    - 远程代理
    - flask request
"""
"""
代理模式，注重对对象某一功能的流程把控和辅助。它可以控制对象做某些事，重心是为了借用对象的功能完成某一流程，而非对象功能如何。
装饰模式，注重对对象功能的扩展，它不关心外界如何调用，只注重对对象功能的加强，装饰后还是对象本身。

对于代理类，如何调用对象的某一功能是思考重点，而不需要兼顾对象的所有功能；
对于装饰类，如何扩展对象的某一功能是思考重点，同时也需要兼顾对象的其它功能，因为再怎么装饰，本质也是对象本身，要担负起对象应有的职责。

作者：Parallel_Lines
链接：https://www.jianshu.com/p/c06a686dae39
来源：简书
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
"""

from abc import ABCMeta, abstractmethod
# 引入ABCMeta和abstractmethod来定义抽象类和抽象方法


class Subject(metaclass=ABCMeta):
    """主题类"""

    def __init__(self, name):
        self.__name = name

    def getName(self):
        return self.__name

    @abstractmethod
    def request(self, content=''):
        pass


class RealSubject(Subject):
    """真实主题类"""

    def request(self, content):
        print("RealSubject todo something...")


class ProxySubject(Subject):
    """代理主题类"""

    def __init__(self, name, subject):
        super().__init__(name)
        self._realSubject = subject

    def request(self, content=''):
        self.preRequest()
        if(self._realSubject is not None):
            self._realSubject.request(content)
        self.afterRequest()

    def preRequest(self):
        print("preRequest")

    def afterRequest(self):
        print("afterRequest")

# --------------- 具体举例 ---------------


class OwnerReception(Subject):
    """本人接收"""

    def __init__(self, name, phoneNum, address=''):
        super().__init__(name)
        self.__phoneNum = phoneNum
        self.__address = address

    def getPhoneNum(self):
        return self.__phoneNum

    def getAddress(self):
        return self.__address

    def request(self, content):
        print("货物主人：%s，手机号：%s" % (self.getName(), self.getPhoneNum()))
        print("接收到一个包裹，包裹内容：%s" % str(content))


class WendyReception(ProxySubject):
    """Wendy代收"""

    def __init__(self, name, receiver):
        super().__init__(name, receiver)

    def preRequest(self):
        print("我是%s的朋友，我来帮他代收快递！" % (self._realSubject.getName() + ""))

    def afterRequest(self):
        print("代收人：%s" % self.getName())


class AgentReception(ProxySubject):
    """中介代收"""

    def __init__(self, name, receiver):
        super().__init__(name, receiver)

    def preRequest(self):
        print(f"{self._realSubject.getAddress()} 属于我接管")

    def afterRequest(self):
        print("代收人：%s" % self.getName())
