from types import MethodType


class InvocationHandler:
    def __init__(self, obj, func):
        self.obj = obj
        self.func = func
        print('InvocationHandler', obj, func)

    def __call__(self, *args, **kwargs):
        """
        在这里添加额外的工作
        """
        print('添加额外的工作 InvocationHandler __call__ :',
              self.func.__name__, args, kwargs)
        return self.func(*args, **kwargs)


class Proxy:
    def __init__(self, real_cls, proxy_cls: 'InvocationHandler'):
        self.real_cls = real_cls
        self.proxy_cls = proxy_cls
        self.handlers = dict()

    def __call__(self, *args, **kwargs):
        print('Proxy __call__')
        self.obj = self.real_cls(*args, **kwargs)
        print('Proxy __call__ end')
        return self

    def __getattr__(self, attr):
        print('Proxy __getattr__', attr)
        isExist = hasattr(self.obj, attr)
        res = None
        if isExist:
            print(attr, 'isExist')
            res = getattr(self.obj, attr)
            if isinstance(res, MethodType):
                if self.handlers.get(res) is None:
                    print('add handlers...self.proxy_cls', self.obj, res)
                    self.handlers[res] = self.proxy_cls(self.obj, res)
                return self.handlers[res]
            else:
                return res
        return res


class ProxyFactory:
    def __init__(self, hcls):
        if issubclass(hcls, InvocationHandler) or hcls is InvocationHandler:
            self.hcls = hcls
        else:
            raise Exception('is not a hanlder class')

    def __call__(self, cls: 'Transaction'):
        return Proxy(cls, self.hcls)


@ProxyFactory(InvocationHandler) # pre_do_something
class Transaction: # owner
    def __init__(self):
        pass

    def make_friend(self, a, b):
        print('make_friend', a, b)

    def reply(self, a):
        print('reply', a)


t = Transaction()
t.make_friend('1', 2)
t.reply('1')
